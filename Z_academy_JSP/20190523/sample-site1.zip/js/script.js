$('button.mobile, ul li a').click(function () {
    $('nav').toggleClass('mobile-nav');
});